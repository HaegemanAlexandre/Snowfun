<?php

require('inc/theme-setup.php');

require('inc/theme-enqueue.php');

require('inc/theme-cleaner.php');

require get_parent_theme_file_path( '/inc/customizer.php' );

