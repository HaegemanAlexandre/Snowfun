</div>
    <footer>
        <img src="<?php echo get_theme_file_uri('public/images/Bandeau_footer.svg'); ?>" alt="" >
    </footer>

</body>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<?php wp_footer() ?>
